
const config = {
  authRequired: false,
  auth0Logout: true,
  secret: 'a long, randomly-generated string stored in env',
  baseURL: 'http://localhost:3000',
  clientID: '9Xe0AUZyH5Q186M2UHJx5U9FwMOf56lj',
  issuerBaseURL: 'https://dev-x2djttsvwzp500rf.us.auth0.com'
};

module.exports=config;